---
name: Browser Research Agent
description: >
  Run browser-backed research agents that capture evidence, citations, and source freshness.
activateOn: browser research, web evidence, citation capture, source comparison
freedomLevel: high
category: research
tags:
  - browser
  - research
  - citations
  - evidence
  - web
---

# Browser Research Agent

Run browser-backed research agents that capture evidence, citations, and source freshness.

## When to Use

Use this Note when a Memoire or Studio run needs browser research, web evidence, citation capture, source comparison.

## Workflow

1. Start with primary sources, then use secondary sources only to find more primary evidence.
2. Record source URL, access date, claim, confidence, and whether the fact is time-sensitive.
3. Use screenshots for visual UI claims and direct API responses for machine-readable facts.
4. Separate quotes from paraphrases and keep quoted excerpts short.
5. Finish with an evidence table and a list of claims that still need verification.


## Sources

- https://developers.openai.com/codex/use-cases
- https://github.com/nousresearch/hermes-agent
- https://docs.openclaw.ai/cli
